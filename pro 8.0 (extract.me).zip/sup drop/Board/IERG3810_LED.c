#include "stm32f10x.h"
#include "IERG3810_LED.h"

// put your procedure and code here
void IERG3810_LED_Init(){
	
	RCC->APB2ENR |= 1<<3; //Enable PB
	
	GPIOB->CRL &= 0xFF0FFFFF; //Enable DS0
	GPIOB->CRL |= 0x00300000;

	RCC->APB2ENR |= 1<<6; //Enable PE
	GPIOE->CRL &= 0xFF0FFFFF; //Enable DS1
	GPIOE->CRL |= 0x00300000;
	
	
	//set ds0, turn it off by set high
	GPIOB->BSRR = 1 << 5;	
	
	//set ds1, turn it off by set high
	GPIOE->BSRR = 1 << 5;
}

void DS0_on(){
	GPIOB->BRR = 1 << 5;	
}

void DS1_on(){
	GPIOE->BRR = 1 << 5;
}

void DS0_off(){
	GPIOB->BSRR = 1 << 5;	
}

void DS1_off(){
	GPIOE->BSRR = 1 << 5;
}
