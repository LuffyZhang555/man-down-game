#include "stm32f10x.h"
#include "IERG3810_KEY.h"

// put your procedure and code here