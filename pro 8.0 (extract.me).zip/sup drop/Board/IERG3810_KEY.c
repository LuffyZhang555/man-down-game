#include "stm32f10x.h"
#include "IERG3810_KEY.h"

// put your procedure and code here
void IERG3810_KEY_Init(){
	
	RCC->APB2ENR |= 1<<6; //Enable PE
	GPIOE->CRL &= 0xFFFF00FF; //Enable key1:PE3, key0:PE2
	GPIOE->CRL |= 0x00008800;
	
	RCC->APB2ENR |= 1<<2; //Enable PA
	GPIOA->CRL &= 0xFFFFFFF0; //Enable keyUp:PA0
	GPIOA->CRL |= 0x00000008;
	
	//set key 1, set to high 
	GPIOE->BSRR = 1 << 3;
	
	//set key 2, set to high 
	GPIOE->BSRR = 1 << 2;
	
	//set key_up, set to low
	GPIOA->BRR = 1;

}