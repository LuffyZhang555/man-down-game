#ifndef _GLOBAL
#define _GLOBAL
#include"stm32f10x.h"

extern int task1HeartBeat;
extern int task2HeartBeat;
extern int task3HeartBeat;
extern int task4HeartBeat;
extern int task5HeartBeat;
extern int suptimer;
#endif
