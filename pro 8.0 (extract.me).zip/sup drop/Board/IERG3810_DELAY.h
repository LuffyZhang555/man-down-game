#ifndef __IERG3810_DELAY_H
#define __IERG3810_DELAY_H
#include "stm32f10x.h"

void Delay(u32 count){
	u32 i;
	for(i=0; i<count; i++);
}

#endif
