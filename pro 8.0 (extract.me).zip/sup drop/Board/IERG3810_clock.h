#ifndef __IERG3810_CLOCK_H
#define __IERG3810_CLOCK_H
#include "stm32f10x.h"

// put procedure header here
void IERG3810_clock_tree_init(void);



#endif
