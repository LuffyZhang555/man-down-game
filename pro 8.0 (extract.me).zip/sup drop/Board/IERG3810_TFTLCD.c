#include "stm32f10x.h"
#include "IERG3810_TFTLCD.h"
#include "FONT.H"


#define LCD_BASE    ((u32)(0x6C000000 | 0x000007FE))
#define LCD         ((LCD_TypeDef *) LCD_BASE)
	


typedef struct{
	u16 LCD_REG;
	u16 LCD_RAM;
} LCD_TypeDef;

//the position of the bars of digital number, from to a to g
/*
	a
f		b
	g
e		c
	d
*/
int bar[7][4] = {
	//startX,lengthX,startY,lengthY
		{10,55,130,10},
		{65,10,75,55},
		{65,10,10,55},
		{10,55,0,10},
		{0,10,10,55},
		{0,10,75,55},
		{10,55,65,10}
};

//u16 colorArray[] = {0x0000,0xFFFF,0x7E0,0xF800,0x1F};

void IERG3810_TFTLCD_WrReg(u16 regval)
{
	LCD->LCD_REG=regval;
}


void IERG3810_TFTLCD_WrData(u16 data)
{
	LCD->LCD_RAM=data;
}

void IERG3810_TFTLCD_SetParameter(void)
{
	IERG3810_TFTLCD_WrReg(0X01);
	IERG3810_TFTLCD_WrReg(0X11);
	IERG3810_TFTLCD_WrReg(0X3A);
	IERG3810_TFTLCD_WrData(0X55);
	IERG3810_TFTLCD_WrReg(0X29);
	IERG3810_TFTLCD_WrReg(0X36);
	IERG3810_TFTLCD_WrData(0XCA);
}




void IERG3810_TFTLCD_Init(void){
	RCC->AHBENR |=1<<8;
	RCC->APB2ENR |=1<<3;
	RCC->APB2ENR |=1<<5;
	RCC->APB2ENR |=1<<6;
	RCC->APB2ENR |=1<<8;
	
	
	GPIOB->CRL&=0XFFFFFFF0;//PB0
	GPIOB->CRL|=0X00000003;

	
	//PORTD
	GPIOD->CRH&=0X00FFF000;
	GPIOD->CRH|=0XBB000BBB;
	GPIOD->CRL&=0XFF00FF00;
	GPIOD->CRL|=0X00BB00BB;
	
	//PORTE
	GPIOE->CRH&=0X00000000;
	GPIOE->CRH|=0XBBBBBBBB;
	GPIOE->CRL&=0X0FFFFFFF;
	GPIOE->CRL|=0XB0000000;
	
	//PORTG 12
	GPIOG->CRH&=0XFFF0FFFF;
	GPIOG->CRH|=0X000B0000;
	GPIOG->CRL&=0XFFFFFFF0;
	GPIOG->CRL|=0X0000000B;
	
	FSMC_Bank1->BTCR[6]=0X00000000;
	FSMC_Bank1->BTCR[7]=0X00000000;
	FSMC_Bank1E->BWTR[6]=0X00000000;
	FSMC_Bank1->BTCR[6]|=1<<12;
	FSMC_Bank1->BTCR[6]|=1<<14;
	FSMC_Bank1->BTCR[6]|=1<<4;
	FSMC_Bank1->BTCR[7]|=0<<28;
	FSMC_Bank1->BTCR[7]|=1<<10;
	FSMC_Bank1->BTCR[7]|=0XF<<8;
	FSMC_Bank1E->BWTR[6] |=0<<28;
	FSMC_Bank1E->BWTR[6] |=0<<0;
	FSMC_Bank1E->BWTR[6] |=3<<8;
	FSMC_Bank1->BTCR[6] |=1<<0;
	IERG3810_TFTLCD_SetParameter();
	//LCD_LIGHT_0N;
	GPIOB->BSRR =1;
	
}

void IERG3810_TFTLCD_DrawDot(u16 x, u16 y, u16 color)
{
	IERG3810_TFTLCD_WrReg(0x2A);
	IERG3810_TFTLCD_WrData(x>>8);
	IERG3810_TFTLCD_WrData(x & 0xFF);
	IERG3810_TFTLCD_WrData(0x01);
	IERG3810_TFTLCD_WrData(0x3F);

	IERG3810_TFTLCD_WrReg(0x2B);
	IERG3810_TFTLCD_WrData(y>>8);
	IERG3810_TFTLCD_WrData(y & 0xFF);
	IERG3810_TFTLCD_WrData(0x01);
	IERG3810_TFTLCD_WrData(0xDF);

	IERG3810_TFTLCD_WrReg(0X2C);
	IERG3810_TFTLCD_WrData(color);

}


void IERG3810_TFTLCD_FillRectangle(u16 color, u16 start_x, u16 length_x, u16 start_y, u16 length_y)
{
	u32 index=0;
	IERG3810_TFTLCD_WrReg(0x2A);
	IERG3810_TFTLCD_WrData(start_x>>8);
	IERG3810_TFTLCD_WrData(start_x & 0xFF);
	IERG3810_TFTLCD_WrData((length_x + start_x - 1) >>8);
	IERG3810_TFTLCD_WrData((length_x + start_x - 1) & 0xFF);
	IERG3810_TFTLCD_WrReg(0x2B);
	IERG3810_TFTLCD_WrData(start_y>>8);
	IERG3810_TFTLCD_WrData(start_y & 0xFF);
	IERG3810_TFTLCD_WrData	((length_y + start_y - 1) >>8);
	IERG3810_TFTLCD_WrData((length_y + start_y - 1) & 0xFF);
	IERG3810_TFTLCD_WrReg(0X2C);
	for (index =0 ; index<length_x * length_y; index++){
		IERG3810_TFTLCD_WrData(color);
	}
}


void IERG3810_TFTLCD_SevenSegment(u16 color, u16 start_x,u16 start_y,u8 digit){
	
	int x= 0;
	int number[10][7] = {
		{0,1,2,3,4,5,-1},
		{1,2,-1,0,0,0,0},
		{0,1,3,4,6,-1,0},
		{0,1,2,3,6,-1,0},
		{1,2,5,6,-1,0,0},
		{0,2,3,5,6,-1,0},
		{0,2,3,4,5,6,-1},
		{0,1,2,-1,0,0,0},
		{0,1,2,3,4,5,6},
		{0,1,2,3,5,6,-1},
	};
	
	for(x =0;x<7;x++){
		if(number[digit][x] == -1)break;
		IERG3810_TFTLCD_FillRectangle(color, start_x + bar[number[digit][x]][0], bar[number[digit][x]][1], start_y + bar[number[digit][x]][2], bar[number[digit][x]][3]);
	}
	//Delay(1000000);
}


void IERG3810_TFTLCD_ShowChar (u16 x, u16 y, u8 ascii, u16 color, u16 bgcolor){
	u8 i, j;
	u8 index;
	u8 height=16,length =8;

	//if(ascii<32 || ascii >127) return;
	//ascii -=32;
  IERG3810_TFTLCD_WrReg(0x2A);
	IERG3810_TFTLCD_WrData(x>>8);
	IERG3810_TFTLCD_WrData(x & 0xFF);
	IERG3810_TFTLCD_WrData((length + x - 1) >>8);
	IERG3810_TFTLCD_WrData((length + x - 1) & 0xFF);

	IERG3810_TFTLCD_WrReg(0x2B);
	IERG3810_TFTLCD_WrData(y>>8);
	IERG3810_TFTLCD_WrData(y & 0xFF);
	IERG3810_TFTLCD_WrData((height + y - 1) >>8);
	IERG3810_TFTLCD_WrData((height + y - 1) & 0xFF);
	IERG3810_TFTLCD_WrReg(0X2C);
	for ( j=0; j<height/8; j++)
	{
	for ( i=0; i<height/2; i++)
		{
			for (index=0; index<length; index++)
			{
				if((asc2_1608[ascii] [index*2+1 - j ]>>i) & 0x01)
				IERG3810_TFTLCD_WrData(color);
				else IERG3810_TFTLCD_WrData(bgcolor);
			}
		}
	}
}


void IERG3810_TFTLCD_Showstick (u16 x, u16 y, u8 ascii, u16 color, u16 bgcolor){
	u8 i, j;
	u8 index;
	u8 height=8,length =8;

	if(ascii<32 || ascii >127) return;
	ascii -=32;
  IERG3810_TFTLCD_WrReg(0x2A);
	IERG3810_TFTLCD_WrData(x>>8);
	IERG3810_TFTLCD_WrData(x & 0xFF);
	IERG3810_TFTLCD_WrData((length + x - 1) >>8);
	IERG3810_TFTLCD_WrData((length + x - 1) & 0xFF);

	IERG3810_TFTLCD_WrReg(0x2B);
	IERG3810_TFTLCD_WrData(y>>8);
	IERG3810_TFTLCD_WrData(y & 0xFF);
	IERG3810_TFTLCD_WrData((height + y - 1) >>8);
	IERG3810_TFTLCD_WrData((height + y - 1) & 0xFF);
	IERG3810_TFTLCD_WrReg(0X2C);
	for ( j=0; j<height/2; j++)
	{
	for ( i=0; i<height/2; i++)
		{
			for (index=0; index<length; index++)
			{
				if((stick_0808[ascii] [index*2+1 - j ]>>i) & 0x01)
				IERG3810_TFTLCD_WrData(color);
				else IERG3810_TFTLCD_WrData(bgcolor);
			}
		}
	}
}

void IERG3810_TFTLCD_ShowChinese(u16 x, u16 y, u8 ascii, u16 color, u16 bgcolor){
	u8 i, j;
	u8 index;
	u8 height=16,length =16;

  
  IERG3810_TFTLCD_WrReg(0x2A);
	IERG3810_TFTLCD_WrData(x>>8);
	IERG3810_TFTLCD_WrData(x & 0xFF);
	IERG3810_TFTLCD_WrData((length + x - 1) >>8);
	IERG3810_TFTLCD_WrData((length + x - 1) & 0xFF);

	IERG3810_TFTLCD_WrReg(0x2B);
	IERG3810_TFTLCD_WrData(y>>8);
	IERG3810_TFTLCD_WrData(y & 0xFF);
	IERG3810_TFTLCD_WrData((height + y - 1) >>8);
	IERG3810_TFTLCD_WrData((height + y - 1) & 0xFF);
	IERG3810_TFTLCD_WrReg(0X2C);
	for ( j=0; j<height/8; j++)
	{
	for ( i=0; i<height/2; i++)
		{
			for (index=0; index<length; index++)
			{
				if((chinse_1616[ascii] [index*2+1 - j ]>>i) & 0x01)
				IERG3810_TFTLCD_WrData(color);
				else IERG3810_TFTLCD_WrData(bgcolor);
			}
		}
	}
}
