#include "stm32f10x.h"
#include "IERG3810_Buzzer.h"

// put your procedure and code here