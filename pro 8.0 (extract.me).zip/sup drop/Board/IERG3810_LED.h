#ifndef __IERG3810_LED_H
#define __IERG3810_LED_H
#include "stm32f10x.h"

// put procedure header here
void IERG3810_LED_Init(void);
void DS0_on(void);
void DS1_on(void);
void DS0_off(void);
void DS1_off(void);



#endif
