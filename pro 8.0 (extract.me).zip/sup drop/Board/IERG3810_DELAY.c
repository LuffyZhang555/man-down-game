#ifndef __IERG3810_DELAY_H
#define __IERG3810_DELAY_H
#include "stm32f10x.h"

// put procedure header here
void Delay(u32);




#endif
