#include "stm32f10x.h"
#include "IERG3810_Buzzer.h"

// put your procedure and code here
void IERG3810_Buzzer_Init(){
	
	RCC->APB2ENR |= 1<<3; //Enable PB
	
	GPIOB->CRH &= 0xFFFFFFF0; //Enable buzzer
	GPIOB->CRH |= 0x00000003;	
	
	//SET BUZZER, turn it off by set low
	GPIOB->BRR = 1 << 8;	
}